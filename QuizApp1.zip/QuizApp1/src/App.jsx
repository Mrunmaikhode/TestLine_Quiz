import React from 'react'
import Quiz from './Component/Quiz'


const App = () => {
  return (
    <div>
      <Quiz/>
    </div>
  )
}

export default App
